using UnityEngine;

public class playerMovement : MonoBehaviour
{   
    public Animator animator;
    private float movement;
    public float movementSpeed =5f;
    private bool facingRight = true;
    public Rigidbody2D rb;
    public float jump = 5f;
    public bool isGround = true;
    void Jump(){
        rb.AddForce(new Vector2(0f,jump), ForceMode2D.Impulse);
    }
    void Start()
    {
        
    }
    void Update(){
        if(Input.GetKey(KeyCode.Space) && isGround){ 
            Jump();
            isGround = false;
        }
        movement = Input.GetAxis("Horizontal");
        if(movement < 0f && facingRight){
            transform.eulerAngles = new Vector3(0f, -180f, 0f);
            facingRight = false;
        }
        else if(movement > 0f && !facingRight){
            transform.eulerAngles = new Vector3(0f, 0f, 0f);
            facingRight = true;  // change direction when the player faces left
        }

        if (Mathf.Abs(movement) > 0f ){
            animator.SetFloat("run",1f);
        }
        else if (movement < 0.1f){
            animator.SetFloat("run",0f);
        }
        if (Input.GetMouseButtonDown(0)){
            animator.SetTrigger("attack");
        }

    }
    private void FixedUpdate(){ 
        transform.position += new Vector3(movement, 0f, 0f ) * Time.fixedDeltaTime * movementSpeed;
    }
    private void OnCollisionEnter2D(Collision2D collision){
        if (collision.gameObject.tag == "Ground"){
            isGround = true;
        }
       
    }
}
