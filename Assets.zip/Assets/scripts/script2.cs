using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{
    public bool inrange = false;
    public Transform player;
    public float enemyRange = 5f; // Adjust this value according to your needs
    public float retrivedist = 2f;
    public float chasespeed = 4f;
    public Animator animator;
    void Start()
    {
        
    }

    void Update()
    {
        if (Vector2.Distance(transform.position, player.position)<= enemyRange){
            inrange = true;
        }
        if (inrange) {
            if (Vector2.Distance(transform.position, player.position)>retrivedist){
                transform.position = Vector2.MoveTowards(transform.position, player.position, chasespeed* Time.deltaTime);
                 animator.SetBool("attack",false);
            }
            else{
                animator.SetBool("attack",true);
            }        
        }    
        
        
    }
    private void OnDrawGizmosSelected(){
        Gizmos.color = Color.white;
        Gizmos.DrawWireSphere(transform.position, enemyRange);
    }
}
